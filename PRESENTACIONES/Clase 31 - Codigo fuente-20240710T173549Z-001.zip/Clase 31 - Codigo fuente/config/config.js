module.exports = {
    secretKey: 'tu_clave_secreta', 
    tokenExpiresIn: '1h'
};

