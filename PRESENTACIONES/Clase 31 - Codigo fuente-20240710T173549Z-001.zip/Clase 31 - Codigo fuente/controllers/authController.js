// Importa el módulo jsonwebtoken para manejar JWT
const jwt = require('jsonwebtoken'); 
// Importa el módulo bcryptjs para cifrar contraseñas
const bcrypt = require('bcryptjs'); 
// Importa el modelo de usuarios (array de usuarios)
const users = require('../models/userModel'); 
// Importa la configuración (clave secreta y duración del token)
const config = require('../config/config'); 

// Función para registrar un nuevo usuario
exports.register = (req, res) => {
    // Extrae el nombre de usuario y la contraseña del cuerpo de la solicitud
    const { username, password } = req.body; 
    // Cifra la contraseña usando bcrypt
    const hashedPassword = bcrypt.hashSync(password, 8); 

    // Crea un nuevo objeto de usuario con un ID único
    const newUser = { id: users.length + 1, username, password: hashedPassword }; 
    // Agrega el nuevo usuario al array de usuarios
    users.push(newUser); 

    // Genera un token JWT para el nuevo usuario
     const token = jwt.sign({ id: newUser.id }, config.secretKey, { expiresIn: config.tokenExpiresIn });
     // Envía el token como respuesta al cliente
     res.status(201).send({ auth: true, token }); 
 };

 // Función para iniciar sesión de un usuario
 exports.login = (req, res) => {
    // Extrae el nombre de usuario y la contraseña del cuerpo de la solicitud 
    const { username, password } = req.body; 
    // Busca el usuario en el array de usuarios por nombre de usuario 
    const user = users.find(u => u.username === username); 
    // Si el usuario no se encuentra, devuelve un error 404 
    if (!user) return res.status(404).send('User not found.'); 
    // Compara la contraseña proporcionada con la contraseña cifrada almacenada
    const passwordIsValid = bcrypt.compareSync(password, user.password); 
    // Si la contraseña no es válida, devuelve un error 401
    if (!passwordIsValid) return res.status(401).send({ auth: false, token: null }); 
    // Genera un token JWT usando el ID del usuario
    const token = jwt.sign({ id: user.id }, config.secretKey, { expiresIn: config.tokenExpiresIn }); 
    // Envía el token JWT al cliente con el estado 200 (OK) 
    res.status(200).send({ auth: true, token }); 
 };
 





// // Función para iniciar sesión de un usuario
// exports.login = (req, res) => {
//     // Extrae el nombre de usuario y la contraseña del cuerpo de la solicitud
//     const { username, password } = req.body; 
//     // Busca el usuario en el array de usuarios por nombre de usuario
//     const user = users.find(u => u.username === username); 

//     // Si el usuario no existe, devuelve un error 404
//     if (!user) return res.status(404).send('Usuario no encontrado.'); 

//     // Compara la contraseña proporcionada con la contraseña cifrada almacenada
//     const passwordIsValid = bcrypt.compareSync(password, user.password); 
    
//     // Si la contraseña no es válida, devuelve un error 401
//     if (!passwordIsValid) return res.status(401).send({ auth: false, token: null }); 

//     // Genera un token JWT para el usuario
//     const token = jwt.sign({ id: user.id }, config.secretKey, { expiresIn: config.tokenExpiresIn });
    
//     // Envía el token como respuesta al cliente
//     res.status(200).send({ auth: true, token }); 
// };


